# Refinery P&ID Component Reference

## P&ID Diagram Component Recognition Guide

This section is designed for AI agents, document parsers, and engineering assistants to identify refinery P&ID symbols, shapes, and equipment tags from uploaded diagrams.

---

# 0. Common P&ID Shapes and What They Represent

| Shape / Symbol Type | Typical Appearance | Component Name | What It Refers To |
|---|---|---|---|
| Vertical Cylinder | Tall vertical vessel | Storage Tank / Separator | Used for storing liquids or separating phases |
| Horizontal Drum | Horizontal cylindrical vessel | Drum / Accumulator | Vapor-liquid separation |
| Circle on Pipe | Small circle connected to line | Pump | Moves liquid through process |
| Tall Tower with Trays | Vertical column with sections | Distillation Column | Separates components by boiling point |
| Box with Flame/Coil | Furnace shape | Heater / Furnace | Adds heat to process stream |
| Shell-and-Tube Shape | Heat exchanger symbol | Heat Exchanger | Transfers heat between streams |
| Cooling Tower Shape | Open-top tower | Cooling Tower | Removes heat from cooling water |
| Small Valve Symbol | Bow-tie or gate symbol | Valve | Opens/closes/regulates flow |
| Instrument Bubble | Small circle with letters | Instrument | Measures or controls process variable |
| Arrow on Line | Direction arrow | Flow Direction | Indicates movement of process fluid |
| Reactor Vessel | Cylindrical vessel with mixing section | Reactor | Chemical conversion process |
| Coil/Reboiler Symbol | Heater connected to column bottom | Reboiler | Supplies heat to column bottom |

---

# 0.1 Instrument Tag Recognition

| Tag Pattern | Meaning |
|---|---|
| FT | Flow Transmitter |
| FC | Flow Controller |
| FCV | Flow Control Valve |
| TT | Temperature Transmitter |
| TC | Temperature Controller |
| TE | Temperature Element / Sensor |
| I/P | Current to Pressure Converter |
| B-xxx | Boiler / Reboiler / Burner |
| CT | Cooling Tower |
| PT | Pressure Transmitter |
| PC | Pressure Controller |
| PCV | Pressure Control Valve |
| LT | Level Transmitter |
| LC | Level Controller |
| P-xxx | Pump |
| Tk-xxx | Tank |
| C-xxx | Column |
| D-xxx | Drum |
| EX-xxx | Heat Exchanger |
| Rx-xxx | Reactor |
| F-xxx | Furnace |
| V-x | Valve |

---

# 0.2 AI Agent Mapping Instructions

When reading refinery P&ID diagrams:

1. Identify equipment by tag prefix:
   - P = Pump
   - Tk = Tank
   - C = Column
   - D = Drum
   - Rx = Reactor
   - EX = Heat Exchanger
   - F = Furnace
   - B = Boiler / Reboiler / Burner
   - CT = Cooling Tower

2. Identify instruments by letter combinations:
   - First letter = process variable
     - F = Flow
     - T = Temperature
     - P = Pressure
     - L = Level
   - Second letter = function
     - T = Transmitter
     - C = Controller
     - I = Indicator
     - E = Element / Sensor
     - V = Valve

   - Special instrument abbreviations:
     - I/P = Current-to-Pressure Converter used in pneumatic control valves

3. Follow arrows to understand process flow direction.

4. Pipes connecting equipment indicate process streams.

5. Control valves connected to controllers indicate automatic control loops.

---

# Refinery P&ID Component Reference

## Overview
This document explains the major components shown in the refinery Process and Instrumentation Diagram (P&ID), along with the function of each item and the meaning of common instrument tags.

---

# 1. Main Equipment and Their Functions

| Tag | Equipment Name | Function / What It Does |
|---|---|---|
| Tk-10 | Storage Tank | Stores feed liquid before processing. |
| P-10 | Pump | Transfers liquid from the storage tank into the process line. |
| V-1 | Isolation Valve | Opens or closes the flow from the storage tank. |
| FT | Flow Transmitter | Measures flow rate in the line and sends the signal to the control system. |
| FC | Flow Controller | Controls the flow rate based on the required setpoint. |
| FCV | Flow Control Valve | Adjusts valve opening automatically to regulate flow. |
| F-105 | Furnace / Heater | Heats the process fluid before it enters the column. |
| TT | Temperature Transmitter | Measures temperature and sends the value to the control system. |
| TC | Temperature Controller | Controls the process temperature by adjusting heat duty. |
| C-105 | Distillation Column | Separates different components of the feed based on boiling point. |
| LT | Level Transmitter | Measures liquid level inside equipment such as drums or columns. |
| LC | Level Controller | Maintains the desired liquid level by controlling valves or pumps. |
| PT | Pressure Transmitter | Measures process pressure. |
| PC | Pressure Controller | Maintains pressure at the desired operating condition. |
| PCV | Pressure Control Valve | Regulates pressure automatically in the system. |
| D-105 | Drum / Separator Drum | Separates vapor and liquid streams from the process. |
| P-12 | Pump | Transfers cooling or recycle fluid from cooling tower section. |
| CT-105 | Cooling Tower | Removes heat from circulating water used in the process. |
| V-2 / V-3 | Manual Valves | Used for isolation or manual flow control. |
| P-13 | Pump | Transfers processed liquid or overhead product to downstream units. |
| P-14 | Pump | Recirculates or transfers liquid from separator drum. |
| Tk-12 | Product Tank | Stores processed product stream. |
| Tk-14 | Product Tank | Stores another separated product stream. |
| EX-105 | Heat Exchanger | Transfers heat between two process streams to improve efficiency. |
| B-105 | Boiler / Reboiler | Supplies heat to the lower section of the column for separation. |
| Rx-105 | Reactor | Chemical reaction vessel where feed is chemically converted. |
| P-15 | Pump | Circulates product through heat exchanger or reactor section. |
| Rx-106 | Cooler / Condenser | Condenses vapor into liquid or cools process stream. |
| V-4 / V-5 / V-6 / V-7 | Isolation / Control Valves | Used to regulate or isolate process streams. |
| Tk-16 | Bottom Product Tank | Stores heavy product or residue from the column bottom. |
| P-11 | Pump | Transfers bottom product from the system to storage. |

---

# 2. Instrumentation Symbols and Meanings

| Symbol | Meaning | Purpose |
|---|---|---|
| F | Flow | Related to measurement/control of fluid flow. |
| T | Temperature | Related to temperature measurement/control. |
| P | Pressure | Related to pressure measurement/control. |
| L | Level | Related to liquid level measurement/control. |
| I | Indicator | Displays process value locally or in control room. |
| C | Controller | Automatically controls the process variable. |
| V | Valve | Controls or isolates fluid flow. |
| Tx | Transmitter | Sends measured signal to control system. |

---

# 3. Typical Process Flow Description

1. Feed liquid is stored in Tk-10.
2. Pump P-10 transfers the feed through a flow control loop.
3. The feed enters Furnace F-105 where it is heated.
4. Heated feed enters Distillation Column C-105.
5. The column separates the feed into lighter and heavier fractions.
6. Overhead vapor goes to Drum D-105 for vapor-liquid separation.
7. Pressure and level are controlled using PCV, LC, and associated pumps.
8. Some streams pass through Reactor Rx-105 and Heat Exchanger EX-105.
9. Cooling and condensation occur in Rx-106.
10. Final products are stored in Tk-12, Tk-14, and Tk-16.

---

# 4. Purpose of the Control Loops

## Flow Control Loop
- Maintains constant feed flow into the process.
- Uses FT, FC, and FCV.

## Temperature Control Loop
- Maintains furnace outlet temperature.
- Uses TT and TC.

## Pressure Control Loop
- Keeps separator drum pressure stable.
- Uses PT, PC, and PCV.

## Level Control Loop
- Maintains liquid level in the column and drum.
- Uses LT and LC.

---

# 5. Summary

This refinery P&ID represents a typical process including:
- Storage tanks
- Pumps
- Heater/Furnace
- Distillation column
- Separator drum
- Reactor
- Heat exchanger
- Cooling system
- Automatic control loops

The instrumentation ensures safe, stable, and efficient operation of the refinery process by controlling:
- Flow
- Temperature
- Pressure
- Liquid level

